sap.ui.define([
	"comsofftekpsp/proyectos/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
