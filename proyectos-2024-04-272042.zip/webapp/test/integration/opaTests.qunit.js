/* global QUnit */

sap.ui.require(["com/sofftek/psp/proyectos/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
